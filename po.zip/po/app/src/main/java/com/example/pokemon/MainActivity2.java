package com.example.pokemon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Bundle a = getIntent().getExtras();
       pokemon s = (pokemon) a.getSerializable("pokemon");
        ImageView img = findViewById(R.id.imageView);
        TextView name = findViewById(R.id.textView);
        TextView attack = findViewById(R.id.textView2);
        TextView def = findViewById(R.id.textView6);

        img.setImageResource(s.getImage());
        name.setText(s.getName());
        attack.setText("attack"+s.getAttack());
        def.setText("defence"+ s.getDefence());

    }
}